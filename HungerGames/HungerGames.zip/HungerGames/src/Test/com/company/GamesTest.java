//package com.company;
//
//import org.junit.jupiter.api.Test;
//
//import java.util.ArrayList;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//class GamesTest {
//    @Test
//    public void TestContestant() {
//        Contestants contestant = new Contestants("c1", 'f', 12.0, 2.0, 35.0, 15.0, 5.0);
//        assertEquals("c1", contestant.getName());
//
//    }
//}