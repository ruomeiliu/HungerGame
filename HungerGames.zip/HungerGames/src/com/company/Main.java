package com.company;

import java.util.ArrayList;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
//Assign random values
        Random r1 = new Random(50);

        ArrayList<Contestants> contestantsList = new ArrayList<>(24);
        for(int x = 0; x < 24; x++){
            if (x <12) {
                contestantsList.add(new Contestants("p" + x, 'm', r1.nextDouble(), r1.nextDouble(), r1.nextDouble(), r1.nextDouble(), r1.nextDouble())); //male
            } else {
                contestantsList.add(new Contestants("fp" + x, 'f', r1.nextDouble(), r1.nextDouble(), r1.nextDouble(), r1.nextDouble(), r1.nextDouble())); //female
            }
        }
        System.out.println("The list of 24 contestants: " + contestantsList);

//Assign contestants type
        ArrayList<Integer> careersIndices = new ArrayList<>();
        while (careersIndices.size() <= 6) {
            int currentIdx = r1.nextInt(24);
            while(careersIndices.contains(currentIdx)) {
                currentIdx = r1.nextInt(24);
            }
            careersIndices.add(currentIdx);
            contestantsList.get(currentIdx).setType("Careers");
        }

        for(int x = 0; x < 24; x++){
            if (!careersIndices.contains(x))  {
                contestantsList.get(x).setType("District");
            }
        }
//Simulate the game
        boolean flag = true;
        int day = 0;
        Games games = new Games();

        while(flag) {
            int contestant1Idx = r1.nextInt(24);
            int contestant2Idx = r1.nextInt(24);
            while(contestant1Idx == contestant2Idx) {
                contestant2Idx = r1.nextInt(24);
            }
            Contestants c1 = contestantsList.get(contestant1Idx);
            Contestants c2 = contestantsList.get(contestant2Idx);
            games.getWinner(c1,c2);                                    //Start the fight
            System.out.println("The winner is " + games.getWinner(c1,c2).toString() + "in day " + day);
            for(Contestants contestants:games.contestants){
            games.getBonus(contestants);                               //Get potential bonus
            }
            if (games.lastFighter()) {                                 //Till last contestant
                flag = false;
            }
            day += 1;
        }
        System.out.println("Only one fighter left and killed by President Snow.");
        System.out.println("Battle ended in day " + day);
    }
}
